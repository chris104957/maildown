# Maildown

A super simple CLI for sending emails

