from maildown.application import application


def run():
    application.run()
